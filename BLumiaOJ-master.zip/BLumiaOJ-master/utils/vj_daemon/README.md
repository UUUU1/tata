VJ Daemon
===

Python 2.x(32bit) to run the daemon tool, and MySQLdb, demjson plugins required.

Source are from [XCOJ v2.0](https://github.com/MaticsL/XCOJ2.0), many thanks. 
Test usage. will be modify when test is done.