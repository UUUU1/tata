<div class="footer bg-blue-light">
&nbsp;&nbsp;Original Code by <a href="https://github.com/zhblue/hustoj">HUSTOJ</a>::Discuss, Modified by BLumia<br/>
&nbsp;&nbsp;Stand-alone Online Judge Discuss Plug-in for <a href="https://github.com/zhblue/hustoj">HUSTOJ</a> and <a href="https://github.com/BLumia/BLumiaOJ">BLumiaOJ</a>.
</div>