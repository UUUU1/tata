<meta charset="utf-8">
<!-- Icons -->
<link rel="icon" href="./sitefiles/favicon.ico">	
<meta name="msapplication-TileColor" content="#FEF2E6">
<meta name="msapplication-TileImage" content="./sitefiles/favicon.png">	
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="./sitefiles/css/bootstrap-cerulean.min.css">
<link rel="stylesheet" href="./sitefiles/css/bootstrap-tour.min.css">
<link rel="stylesheet" href="./sitefiles/css/prettify.css" type="text/css">
<link rel="stylesheet" href="./sitefiles/css/font-awesome.min.css" type="text/css">
<link rel="stylesheet" href="./sitefiles/css/nprogress.css">

<!--[if lte IE 6]>
<link rel="stylesheet" type="text/css" href="./sitefiles/css/bootstrap-ie6.css">
<link rel="stylesheet" type="text/css" href="./sitefiles/css/ie.css">
<![endif]-->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="./sitefiles/js/html5shiv.js"></script>
  <script src="./sitefiles/js/respond.min.js"></script>
<![endif]-->

<!--[if lt IE 7]>
  <link rel="stylesheet" href="./sitefiles/css/font-awesome-ie7.css" type="text/css">
<![endif]-->

<link rel="stylesheet" href="./sitefiles/css/bearkidframe.css" type="text/css">

<!-- js文件 -->
<script src="./sitefiles/js/jquery.min.js"></script>
<script src="./sitefiles/js/bootstrap.min.js"></script>
<script src="./sitefiles/js/bootstrap-tour.min.js"></script>
<script src="./sitefiles/js/prettify.js"></script>
<script src="./sitefiles/js/cnblogs.js"></script>
<script src="./sitefiles/js/nprogress.js"></script>
