
	<body>
		<?php require("./pages/components/navbar.php");?>
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-xs-12">
					<div class="btn-group" role="group" id="oj-ps-pager">
						<?php
							for($totnum = 1,$pagenum = 1;$totnum<=$totalCount;$totnum+=$PAGE_ITEMS,$pagenum++) {
								$btnClass = ($pagenum == $p) ? "btn-primary" : "btn-default";
								echo "<a type='button' class='btn {$btnClass}' href='problemset.php?p={$pagenum}'>{$pagenum}</a>";
							}
						?>
					</div>
				</div>
				<div class="col-md-3 col-xs-6">
					<form method="get" action="./problem.php">
					<div class="input-group">
						<input type="text" class="form-control" name="pid" placeholder="输入题目编号">
						<span class="input-group-btn">
							<button class="btn btn-default" type="button">走起</button>
						</span>
					</div><!-- /input-group -->
					</form>
				</div><!-- /.col-lg-3 -->
				<div class="col-md-3 col-xs-6">
				<form method="get">
					<div class="input-group">
						<input type="text" name="wd" class="form-control" placeholder="输入标题关键字">
						<span class="input-group-btn">
							<button class="btn btn-default" type="submit">搜索</button>
						</span>
					</div><!-- /input-group -->
				</form>
				</div><!-- /.col-lg-3 -->
			</div><!-- /.row -->
			<div class="row">
				<div class="col-md-12">
					<table class="table table-striped table-hover" id="tableID">
						<thead>
							<tr>
								<th width="5%">AC</th>
								<th width="5%">ID</th>
								<th width="40%">Title</th>
								<th width="20%">Difficulty</th>
								<th width="16%">Source</th>
								<th width="14%">AC/Submit</th>
							</tr>
						</thead>
						<tbody id="oj-ps-problemlist">
						<?php foreach ($problemList as $row) { //problem list ------------  ?>
							<tr>
								<?php 
									if ($row['submit'] == 0) {
										$pctText = "N/A";
										$procBarNum = 0;
										$pctNum = 0;
									} else {
										$pctNum = ($row['accepted']/$row['submit'])*100;
										$procBarNum = (1-($row['accepted']/$row['submit']))*100;
										$pctText = sprintf("%.2f%%",$pctNum);
									}
								?>
								<td>
								<?php 
									if ($row['defunct'] == 'Y') echo "<i class='fa fa-lock'></i>";
									if (isset($probIDUCList[$row['problem_id']])) echo "<i class='fa fa-clock-o'></i>";
									if (isset($probStatusList[$row['problem_id']])) {
										$thisProbState = $probStatusList[$row['problem_id']];
										switch($thisProbState) {
										case "accepted":
											echo "<i style='color: green;' class='fa fa-check'></i>";
											break;
										default:
											echo "<i style='color: yellow;' class='fa fa-dot-circle-o'></i>";
											break;
										}
									}
								?>
								</td>
								<td><?php echo $row['problem_id'];?></td>
								<td>
									<a href="problem.php?pid=<?php echo $row['problem_id'];?>"><?php echo $row['title'];?></a>
									<!--<div class="tr-tag"><span>搜索</span></div>-->
								</td>
								<td><div class="progress maxwidth150px"><div class="progress-bar" style="width:<?php echo $procBarNum;?>%;"></div></div></td>
								<td><?php echo utf8_substr($row['source'],0,14);?></td>
								<td>(<?php echo $row['accepted']." / ".$row['submit'];?>) <?php echo $pctText;?></td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div><!--main wrapper end-->
		<?php require("./pages/components/footer.php");?>
	<script type="text/javascript">
	var tour = new Tour({
		backdrop: true,
		debug: true,
		steps: [
		{
			element: "#oj-ps-pager",
			title: "This is Pager",
			content: "You can switch page by click here",
			placement: "bottom"
		},
		{
			element: "#oj-ps-problemlist",
			title: "This is the Problem list",
			content: "Click a problem title to challenge the problem.",
			placement: "top"
		}]
	});
	</script>
	</body>